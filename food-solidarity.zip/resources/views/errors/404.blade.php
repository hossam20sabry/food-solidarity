@extends('errors::layout')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('Not Found'))
{{-- @section('img')
<img src="{{asset('/home/img/error.png')}}" alt="Not Found" style="width: 80px; height: 80px">
@endsection --}}
