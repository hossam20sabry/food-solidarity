<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <?php if(session('status')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger ">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
    
    <form action="<?php echo e(route('admin.authTypes.update', ['authType' => $type->id])); ?>" method="post" id="create">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="row box_shadow m-2 p-2 my-3">
            <div class="col-12 border-bottom">
                <h4>Update Author Type</h4>
            </div>
            <div class="col-md-4">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($type->name); ?>">
            </div>
            <div class="col-md-4">
                <label for="flag" class="form-label">Type Donor = 0 | Type Beneficiary = 1</label>
                <input type="number" min="0" max="1"  value="<?php echo e($type->flag); ?>" name="flag" class="form-control">
            </div>
            <div class="col-md-4 mb-3">
                <label for="name" class="form-label">_</label>
                <button type="submit" class="btn btn-primary w-100">Update</button>
            </div>
        </div>
    </form>
            
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/admin/authType/edit.blade.php ENDPATH**/ ?>