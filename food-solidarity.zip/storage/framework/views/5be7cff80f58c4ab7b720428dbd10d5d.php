

<?php $__env->startSection('content'); ?>
<div class="mainSpinner d-none" id="mainSpinner">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only"></span>
    </div>
</div>
<?php if(session()->has('error')): ?>
<div class="container">
        <div class="alert alert-danger m-2">
            <?php echo e(session()->get('error')); ?>

        </div>
</div>
<?php endif; ?>

<div class="container">
    <div class="row min-height d-flex flex-column justify-content-center align-items-center" style="position: relative;">
        
        <div class="row d-flex justify-content-center align-items-center box_shadow pos add-donation-height w-100">
            <div class="col-md-6">
                <form action="<?php echo e(route('dist.donations.cooked')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="donation_id" id="donation_id"  value="<?php echo e($donation->id); ?>">
                    <div class="border-bottom">
                        <h5 class="">Donate Cooked Meals</h5>
                        <p class=" text-muted">Quantity Measured by Meal</p>
                    </div>
                    <div class="mt-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="quantity" placeholder="Enter quantity" name="quantity" aria-describedby="emailHelp">
                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mt-3">
                        <label for="cooked_time" class="form-label">Cooked Time</label> 
                        <input type="datetime-local" class="form-control" placeholder="" id="cooked_time" name="cooked_time">
                        <?php $__errorArgs = ['cooked_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-danger"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-success w-25">Submit</button>
                    </div>
                </form>
            </div>
        </div>


        <img src="<?php echo e(asset('/home/img/main3.png')); ?>" alt="..." class="bg-size img_res">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
        var today = new Date();

        var sixDaysAgo = new Date(today);
        sixDaysAgo.setDate(today.getDate() - 6);

        var formattedDate = sixDaysAgo.toISOString().slice(0, 16);

        document.getElementById("cooked_time").min = formattedDate;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/dist/donation/create2.blade.php ENDPATH**/ ?>