<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <?php if(session('status')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-success ">
            <?php echo e(session('status')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger ">
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger ">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
    <div class="row center flex-space-between mx-1">
    
        <div class="col-md-4 box_shadow p-3 my-1">
            <button class="btn btn-primary w-100 text-capitalize" id="create_btn">Create Food Type</a>
        </div>
        
    </div>
    <form action="<?php echo e(route('admin.FoodTypes.store')); ?>" method="post" id="create" class="d-none">
        <?php echo csrf_field(); ?>
        <div class="row box_shadow m-2 p-2 my-3">
            <div class="col-12 border-bottom">
                <h4>Create Food Type</h4>
            </div>
            <div class="col-md-4">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="col-md-4">
                <label for="flag" class="form-label">Type: 0 = Dry, 1 = Protein</label>
                <input type="number" min="0" value="0" max="1" name="flag" class="form-control">
            </div>
            <div class="col-md-4 mb-3">
                <label for="name" class="form-label">_</label>
                <button type="submit" class="btn btn-primary w-100">Store</button>
            </div>
        </div>
    </form>
            
    </div>
<div class="container mt-3">
    
    <?php if(isset($types) && $types->count() > 0): ?>
    <table class="table table-secondary">
        <thead>
            <tr>
                <th class="table_responsive">id</th>
                <th>name</th>
                <th>Type</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="table_responsive"><?php echo e($type->id); ?></th>
                <td><?php echo e($type->name); ?></td>
                <td><?php if($type->flag == 0): ?> Dry <?php else: ?> Protein <?php endif; ?></td>
                <td>
                    <a href="<?php echo e(route('admin.FoodTypes.edit', $type->id)); ?>">
                        <button class="btn btn-primary">Edit</button>
                    </a>
                </td>
                <td>
                    <form action="<?php echo e(route('admin.FoodTypes.destroy', $type->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <h3 class="text-center">No Food Types</h3>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var create = document.querySelector('#create');
    var create_btn = document.querySelector('#create_btn');

    create_btn.addEventListener('click', function(){
        create.classList.toggle('d-none');
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/admin/FoodType/index.blade.php ENDPATH**/ ?>