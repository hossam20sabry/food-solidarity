

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <div class="row mb-4">
        <div class="col-12 box_shadow p-3 rounded">
            <h4 class="text-capitalize">Dashboard</h4>
            <p class="text-capitalize">Welcome to your dashboard.</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Start\multiAuth\multiAuth(Breeze)\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>