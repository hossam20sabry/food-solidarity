<?php $__env->startSection('content'); ?>
    <div class="mainBackground">
        <div class="container">
            <div class="content">
                <h1 class="color-green h1-text-responsive">Food Solidarity</h1>
                <h2 class="color-green text-responsive2">Between Institutions and Individuals</h2>
                <div class="background-text-responsive">
                    <p class="text-responsive">In a world of plenty, it is disheartening to acknowledge that millions of our fellow<br>
                        human beings go to bed hungry every night. The stark reality of food insecurity persists<br>
                        despite an abundance of resources, and it demands our urgent attention. This essay serves<br>
                        as a call to action, aiming to raise awareness about the concept of food solidarity and inspire<br>
                        individuals to extend a helping hand to those who have no food.</p>
                </div>
                <?php if(Auth::guard('web')->guest() && Auth::guard('dist')->guest()): ?>
                    <a href="<?php echo e(route('select.register')); ?>" class="btn btn-success my-3">Get Started</a>
                <?php endif; ?>
            </div>
        </div>
        <img src="<?php echo e(asset('/home/img/mainBackgound.png')); ?>" alt="background"  style="height: 100vh; width: 100%">
    </div>

    <?php if(isset($topDonors) && $topDonors->count() > 0): ?>
    <div class="container mt-5">
        <h1 class="color-green mb-4 border-bottom py-2">Top Donors</h1>
        <table class="table table-light  table-striped">
            <tr>
                <th style="max-width: 70px; overflow-x: scroll">Name</th>
                <th style="max-width: 100px; overflow-x: scroll">Email</th>
                <th>Total Quantity</th>
            </tr>
            <?php $__currentLoopData = $topDonors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topDonor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="max-width: 70px; overflow-x: scroll"><?php echo e($topDonor->name); ?></td>
                <td style="max-width: 100px; overflow-x: scroll"><?php echo e($topDonor->email); ?></td>
                <td>
                    <?php
                        $totalQuantity = 0;
                        foreach ($topDonor->donations as $donation) {
                            $totalQuantity += $donation->quantity;
                        }
                    ?>
                    <?php echo e($totalQuantity); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <?php endif; ?>

    <?php if(isset($article)): ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-6">                        
                <p id="textFilter"><?php echo str_replace('s1p1a1ce', '<br>', $article->text); ?></p>
            </div>
            <div class="col-sm-6 mb-5">
                <div class="row">
                    <div class="col">
                        <img src="<?php echo e(asset('/images/' . $article->img)); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/welcome.blade.php ENDPATH**/ ?>