<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row min-height d-flex flex-column justify-content-center align-items-center" style="position: relative;">
            <div class="col-md-6">
                <h3 class="text-success">Donation Details</h3>
                <table class="table table-light">
                    <tr>
                        <th>ID</th>
                        <td><?php echo e($donation->id); ?></td>
                    </tr>
                    <?php if($donation->status == 'matched'): ?>
                    <tr>
                        <th>Need ID</th>
                        <td><?php echo e($donation->need->id); ?></td>
                    </tr>
                    <tr>
                        <th>Beneficiary</th>
                        <td><?php echo e($donation->need->user->name); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($donation->need->user->email); ?></td>
                    </tr>
                    <tr>
                        <th>Phone</th>
                        <td><?php echo e($donation->need->user->phone); ?></td>
                    </tr>
                    <tr>
                        <th>Location</th>
                        <td><a href="<?php echo e($donation->need->user->location_link); ?>" target="_blank"><?php echo e($donation->need->user->location_link); ?></a></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th>Quantity</th>
                        <td><?php echo e($donation->quantity); ?></td>
                    </tr>
                    <tr>
                        <th>Type</th>
                        <td><?php if($donation->donation_type == 1): ?> Dry <?php elseif($donation->donation_type == 2): ?> Cooked Meals <?php elseif($donation->donation_type == 3): ?> Proteins <?php endif; ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td class="text-capitalize" <?php if($donation->status == 'matched'): ?> class="text-success" <?php endif; ?>><?php echo e($donation->status); ?></td>
                    </tr>
                    <tr>
                        <th>Added At</th>
                        <td><?php echo e($donation->created_at->toDayDateTimeString()); ?></td>
                    </tr>
                    <?php if(isset($donation->foods) && $donation->foods->count() > 0): ?>
                    <tr>
                        <th>Foods</th>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $donation->foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($food->name); ?> - <?php echo e($food->quantity); ?> Kg</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php if(isset($donation->cookedMeals) && $donation->cookedMeals->count() > 0): ?>
                    <tr>
                        <th>Foods</th>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $donation->cookedMeals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-capitalize"><?php echo e($food->quantity); ?> Meal</li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
            </div>

            <img src="<?php echo e(asset('/home/img/main3.png')); ?>" alt="..." class="bg-size img_res">

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/dist/donation/show.blade.php ENDPATH**/ ?>