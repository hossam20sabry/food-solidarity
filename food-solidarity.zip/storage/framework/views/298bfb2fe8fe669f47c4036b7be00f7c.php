

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <div class="row mb-4">
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Total Donations</h5>
                    <p class="card-text red"><?php echo e($totalDonations); ?></p>
                    </div>
                </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Total Donations Matched</h5>
                    <p class="card-text red"><?php echo e($totalDonationsMatched); ?></p>
                    </div>
                </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Today Donations</h5>
                    <p class="card-text red"><?php echo e($totalDonationsDay); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Today Matched Donations</h5>
                    <p class="card-text red"><?php echo e($donationsDay); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Week Donations</h5>
                    <p class="card-text red"><?php echo e($totalDonationsWeek); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Week Donations</h5>
                    <p class="card-text red"><?php echo e($donationsWeek); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Month Donations</h5>
                    <p class="card-text red"><?php echo e($totalDonationsMonth); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Month Matched Donations</h5>
                    <p class="card-text red"><?php echo e($donationsMonth); ?></p>
                </div>
            </div>
        </div>

        
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Total Complaints unsolved</h5>
                    <p class="card-text red"><?php echo e($UnsolvedComplaints); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Total Complaints solved</h5>
                    <p class="card-text red"><?php echo e($solvedComplaints); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Complaints unsolved Today</h5>
                    <p class="card-text red"><?php echo e($UnsolvedComplaintsDay); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Complaints solved Today</h5>
                    <p class="card-text red"><?php echo e($solvedComplaintsDay); ?></p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Complaints unsolved Week</h5>
                    <p class="card-text red"><?php echo e($UnsolvedComplaintsWeek); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Complaints solved Week</h5>
                    <p class="card-text red"><?php echo e($solvedComplaintsWeek); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Complaints unsolved Month</h5>
                    <p class="card-text red"><?php echo e($UnsolvedComplaintsMonth); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3  mb-3 mb-sm-3">
            <div class="card text-bg-light">
                <div class="card-body">
                    <h5 class="card-title">Complaints solved Month</h5>
                    <p class="card-text red"><?php echo e($solvedComplaintsMonth); ?></p>
                </div>
            </div>
        </div>

    </div>
    <?php if($topDonors->count() > 0): ?>
    <div class="row">
        <h4 class="text-green border-bottom p-1">Top Donors</h4>
        <table class="table table-secondary">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Donations Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $topDonors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topDonor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($topDonor->name); ?></td>
                    <td><?php echo e($topDonor->email); ?></td>
                    <td>
                        <?php
                            $totalQuantity = 0;
                            foreach ($topDonor->donations as $donation) {
                                $totalQuantity += $donation->quantity;
                            }
                        ?>
                        <?php echo e($totalQuantity); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>