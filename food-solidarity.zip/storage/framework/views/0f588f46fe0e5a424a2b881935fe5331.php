<?php $__env->startSection('content'); ?>
    <div class="container min-height mt-3 d-flex flex-column  align-items-center">
        <?php if(count($notifications) > 0): ?>
            <div class="row d-flex flex-column  align-items-center box_shadow p-3">
                <h3 class="text-success">Notifications</h3>
                <p class="text-muted">Here you can see all of your notifications</p>
                <hr>

                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-3 border <?php if(!$notification->read_at): ?> border-success <?php endif; ?> rounded p-3">
                    <div class="row">
                        <div class="col-6">
                            <h5 class="text-success"><?php echo e($notification->data['head']); ?></h5>
                        </div>
                        <div class="col-6 d-flex justify-content-end">
                            <p class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></p>
                        </div>
                        <div class="col-sm-9">
                            <p class="text-muted"><span style="font-weight: bold"><?php echo e($notification->data['greeting']); ?></span> . <?php echo e($notification->data['body']); ?></p>
                        </div>
                        <?php if(isset($notification->data['url'])): ?>
                        <div class="col-sm-3 d-flex justify-content-end">
                            <a href="<?php echo e($notification->data['url']); ?>?notification_id=<?php echo e($notification->id); ?>" class="btn <?php if(!$notification->read_at): ?> btn-success <?php else: ?> btn-light <?php endif; ?>">Get Details</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        <?php else: ?>
            <h3 class="mt-3">No Notifications</h3>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/notifications.blade.php ENDPATH**/ ?>