<?php $__env->startSection('content'); ?>
<div class="min_hei">

    <div class="container my-4">
        <?php if(session('status')): ?>
        <div class="row">
            <div class="col-md-12 box_shadow alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="row">
            <div class="col-md-12 box_shadow alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        </div>
        <?php endif; ?>


        <div class="row center flex-space-between mx-1">
        
            <div class="col-md-4 box_shadow p-3 my-1">
                <button  class="btn btn-success w-100 text-capitalize" id="create_btn">Add Needs</button>
            </div>
            <form action="<?php echo e(route('needs.store')); ?>" method="post" id="create" class="d-none">
                <?php echo csrf_field(); ?>
                <div class="row box_shadow  py-2 my-3">
                    <div class="col-12 border-bottom">
                        <h4>Request new Donation</h4>
                    </div>
                    <div class="col-md-4 my-2">
                        <label for="name" class="form-label">Donation Type</label>
                        <select name="type" class="form-select" id="">
                            <option value="">Select</option>
                            <option value="1">Dry Food</option>
                            <option value="2">Cooked Meals</option>
                            <option value="3">Proteins <span class="text-muted">(meat, fish, eggs)</span></option>
                        </select>
                    </div>
                    <div class="col-md-4 my-2">
                        <label for="qty" class="form-label">Quantity</label>
                        <input type="number" name="qty" placeholder="Quantity" min="1" class="form-control">
                    </div>
                    
                    <div class="col-md-4 my-2">
                        <label for="name" class="form-label">_</label>
                        <button type="submit" class="btn btn-success w-100">Store</button>
                    </div>
                </div>
            </form>
            
        </div>
                
    </div>

    <div class="container mt-3">
        
        <?php if(isset($needs) && $needs->count() > 0): ?>
        <h4 class="text-green border-bottom p-1">Needs List</h4>
        <table class="table table-light table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Type</th>
                    <th class="table_responsive">Quantity</th>
                    <th class="table_responsive">Status</th>
                    <th class="table_responsive">Added At</th>
                    <th>Show</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $needs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $need): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($need->status != 'pending'): ?>
                <tr>
                    <th><?php echo e($need->id); ?></th>
                    <td><?php if($need->donation_type_id == 1): ?> Dry <?php elseif($need->donation_type_id == 2): ?> Cooked Meals <?php elseif($need->donation_type_id == 3): ?> Proteins <?php endif; ?></td>
                    <td class="table_responsive"><?php echo e($need->quantity); ?></td>
                    <td class="table_responsive text-uppercase text-success"><?php echo e($need->status); ?></td>
                    <td class="table_responsive"><?php echo e($need->created_at->toDayDateTimeString()); ?></td>
                    <td>
                        <a href="<?php echo e(route('needs.show', $need->id)); ?>">
                            <button class="btn btn-success">Details</button>
                        </a>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <h3 class="text-center">No needs Added</h3>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var create = document.querySelector('#create');
    var create_btn = document.querySelector('#create_btn');

    create_btn.addEventListener('click', function(){
        create.classList.toggle('d-none');
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/ben/index.blade.php ENDPATH**/ ?>