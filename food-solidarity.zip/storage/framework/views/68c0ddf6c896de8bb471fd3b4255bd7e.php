

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <?php if(session('success')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <?php endif; ?>
    
    <form action="<?php echo e(route('admin.benAnswersComplains.store', $complaint->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row box_shadow m-2 p-2 my-3">
            <div class="col-12 border-bottom">
                <h4>Send Answer to <?php echo e($complaint->user->name); ?></h4>
            </div>
            <div class="col-md-12">
                <label for="text" class="form-label">Complain</label>
                <textarea  id="" rows="10" class="p-2" style="width: 100%"><?php echo e($complaint->content); ?></textarea>
            </div>
            
            <div class="col-md-6 my-3">
                <button type="submit" class="btn btn-primary w-50">Answered</button>
            </div>
        </div>
    </form>
            
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/admin/benAnswerComplaint/create.blade.php ENDPATH**/ ?>