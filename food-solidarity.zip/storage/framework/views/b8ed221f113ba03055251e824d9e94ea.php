

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <?php if(session('status')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-success ">
            <?php echo e(session('status')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger ">
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <?php endif; ?>
    <div class="row center flex-space-between mx-1">
    
        <div class="col-md-4 box_shadow p-3 my-1">
            <a href="<?php echo e(route('admin.register')); ?>" class="btn btn-primary w-100 text-capitalize">add new Admin</a>
        </div>
        
    </div>
</div>
<div class="container mt-3">
    
    <?php if(isset($admins) && $admins->count() > 0): ?>
    <table class="table table-secondary">
        <thead>
            <tr>
                <th class="table_responsive">id</th>
                <th class="table_responsive">name</th>
                <th>Email</th>
                <th>Main</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="table_responsive"><?php echo e($admin->id); ?></th>
                <td class="table_responsive"><?php echo e($admin->name); ?></td>
                <td ><?php echo e($admin->email); ?></td>
                
                <td>
                    <?php if($admin->main == 0): ?>
                    <form action="<?php echo e(route('admin.main')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($admin->id); ?>">
                        <button type="submit" class="btn btn-primary">Main</button>
                    </form>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($admin->main == 0): ?>
                    <form action="<?php echo e(route('admin.delete')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="id" value="<?php echo e($admin->id); ?>">
                        <button type="submit" id="submit" class="btn btn-danger">Delete</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <h3 class="text-center">No admins</h3>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Start\multiAuth\multiAuth(Breeze)\resources\views/admin/index.blade.php ENDPATH**/ ?>