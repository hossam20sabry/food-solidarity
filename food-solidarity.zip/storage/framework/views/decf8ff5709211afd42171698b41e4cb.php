

<?php $__env->startSection('content'); ?>
    <h1>Distributors Dashboard</h1>
    <form action="<?php echo e(route('dist.logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="dropdown-item">log out</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dist.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/dist/index.blade.php ENDPATH**/ ?>