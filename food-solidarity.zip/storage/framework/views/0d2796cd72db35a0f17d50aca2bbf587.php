

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <div class="row mb-4">
        <div class="col-12 box_shadow p-3 rounded">
            <h4 class="text-capitalize">Profile information</h4>
            <p class="text-capitalize">Update your account's profile information and email address.</p>
            <form action="<?php echo e(route('admin.profile.update', ['guard' => 'admin'])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                

                <div class="mb-3">
                    <label for="name">Name</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $admin->name)); ?>" class="form-control">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-error">
                        <p class="text-danger mb-3"><?php echo e($message); ?></p>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="email">Email</label>
                    <input type="email" name="email" value="<?php echo e(old('email', $admin->email)); ?>" class="form-control">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-error">
                        <p class="text-danger mb-3"><?php echo e($message); ?></p>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                

                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

                <?php if(session('status') === 'profile-updated'): ?>
                    <div>
                        <p class="text-sm mt-2 text-gray-800 dark:text-gray-200">
                            <?php echo e(__('Saved.')); ?>

                        </p>
                    </div>
                <?php endif; ?>

                

            </form>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-12 box_shadow p-3 rounded">
            <h4 class="text-capitalize">Update Password</h4>
            <p class="text-capitalize">Ensure your account is using a long, random password to stay secure.</p>
            <form action="<?php echo e(route('admin.password.update', ['guard' => 'admin'])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="mb-3">
                    <label for="current_password">Current Password</label>
                    <input type="password" name="current_password" class="form-control">
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-error">
                        <p class="text-danger mb-3"><?php echo e($message); ?></p>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="password">New Password</label>
                    <input type="password" name="password" class="form-control">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-error">
                        <p class="text-danger mb-3"><?php echo e($message); ?></p>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="password_confirmation">Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-control">
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-error">
                        <p class="text-danger mb-3"><?php echo e($message); ?></p>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>

                <?php if(session('status') === 'password-updated'): ?>
                    <div>
                        <p class="text-sm mt-2 text-gray-800 dark:text-gray-200">
                            <?php echo e(__('Saved.')); ?>

                        </p>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <form action="<?php echo e(route('admin.profile.destroy')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <div class="row">
            <div class="col-12 box_shadow p-3 rounded">
                <h4 class="text-capitalize">Delete Account</h4>
                <p>Once your account is deleted, all of its resources and data will be permanently deleted.</p>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-error">
                    <p class="text-danger mb-3"><?php echo e($message); ?></p>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="my-3">
                    

                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">Delete Account</button>

                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Delete Account</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <div class="modal-body">
                                        <h4 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                                            <?php echo e(__('Are you sure you want to delete your account?')); ?>

                                        </h4>
                            
                                        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                                            <?php echo e(__('Once your account is deleted, all of its resources and data will be permanently deleted. Please enter your password to confirm you would like to permanently delete your account.')); ?>

                                        </p>
                                        <div class="mb-3 p-2">
                                            <label for="password">Password</label>
                                            <input type="password" name="password" class="form-control">
                                            
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger">Delete Account</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
        </form>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Start\multiAuth\multiAuth(Breeze)\resources\views/admin/profile/edit.blade.php ENDPATH**/ ?>