<?php echo e($slot); ?>

<?php /**PATH E:\capastone-project\food-solidarity\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>