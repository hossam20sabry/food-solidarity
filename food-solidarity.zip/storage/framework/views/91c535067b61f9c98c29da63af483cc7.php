<?php $__env->startSection('content'); ?>
<div class="min_hei">

    <div class="container my-4">
        <?php if(session('status')): ?>
        <div class="row">
            <div class="col-md-12 box_shadow alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="row">
            <div class="col-md-12 box_shadow alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        </div>
        <?php endif; ?>
        <div class="row center flex-space-between mx-1">
        
            <div class="col-md-4 box_shadow p-3 my-1">
                <form action="<?php echo e(route('dist.donations.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button  class="btn btn-success w-100 text-capitalize" id="create_btn">Add Donation</button>
                </form>
            </div>
            
        </div>
                
    </div>

    <div class="container mt-3">
        
        <?php if(isset($donations) && $donations->count() > 0): ?>
        <h4 class="text-green border-bottom p-1">Donations List</h4>
        <table class="table table-light table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>Type</th>
                    <th class="table_responsive">Quantity</th>
                    <th class="table_responsive">Status</th>
                    <th class="table_responsive">Added At</th>
                    <th>Show</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                    <th><?php echo e($donation->id); ?></th>
                    <td><?php if($donation->donation_type == 1): ?> Dry <?php elseif($donation->donation_type == 2): ?> Cooked Meals <?php elseif($donation->donation_type == 3): ?> Proteins <?php endif; ?></td>
                    <td class="table_responsive"><?php echo e($donation->quantity); ?></td>
                    <td class="table_responsive text-uppercase text-success"><?php echo e($donation->status); ?></td>
                    <td class="table_responsive"><?php echo e($donation->created_at->toDayDateTimeString()); ?></td>
                    <td>
                        <a href="<?php echo e(route('dist.donations.show', $donation->id)); ?>">
                            <button class="btn btn-success">Details</button>
                        </a>
                    </td>
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <h3 class="text-center">No Donations Added</h3>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/dist/donation/index.blade.php ENDPATH**/ ?>