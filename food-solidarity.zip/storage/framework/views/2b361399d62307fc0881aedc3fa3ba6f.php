

<?php $__env->startSection('content'); ?>
<div class="mainSpinner d-none" id="mainSpinner">
    <div class="spinner-border text-primary" role="status">
        <span class="sr-only"></span>
    </div>
</div>
<?php if(session()->has('error')): ?>
<div class="container">
        <div class="alert alert-danger m-2">
            <?php echo e(session()->get('error')); ?>

        </div>
</div>
<?php endif; ?>



<?php if($errors->any()): ?>
<div class="container">
        <div class="alert alert-danger m-2">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>
<?php endif; ?>

<div class="container">
    <?php if(session()->has('success')): ?>
        <div class="container">
                <div class="alert alert-success m-2">
                    <?php echo e(session()->get('success')); ?>

                </div>
        </div>
    <?php endif; ?>
    <div class="row min-height d-flex flex-column justify-content-center align-items-center" style="position: relative;">
        
        <div class="row d-flex justify-content-center align-items-center box_shadow pos add-donation-height w-100" id="phase1">

            <div class="col-md-6 p-2 ">
                <div class="row d-flex justify-content-center ">

                    <h5 class="">Send Complaint</h5>

                    <form action="<?php echo e(route('complaints.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="my-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Complaint Content:</label>
                            <textarea class="form-control" name="text"  id="exampleFormControlTextarea1" rows="5"></textarea>
                            <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="my-3">
                            <button type="submit" class="btn btn-success w-25">Submit</button>
                        </div>
                    </form>

                </div>
            </div>

        </div>

        <img src="<?php echo e(asset('/home/img/main3.png')); ?>" alt="..." class="bg-size img_res">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/ben/complaints/create.blade.php ENDPATH**/ ?>