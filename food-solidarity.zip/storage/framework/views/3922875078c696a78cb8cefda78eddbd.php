

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <?php if(session('status')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-success ">
            <?php echo e(session('status')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger ">
            <?php echo e(session('error')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="row">
        <div class="col-md-12 box_shadow alert alert-danger ">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
<div class="container mt-3">
    
    <?php if(isset($complaints) && $complaints->count() > 0): ?>
    <table class="table table-secondary">
        <thead>
            <tr>
                <th class="table_responsive">id</th>
                <th>name</th>
                <th>Answer</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th class="table_responsive"><?php echo e($complaint->id); ?></th>
                <td><?php echo e($complaint->dist->name); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.answersComplains.create', $complaint->id)); ?>">
                        <button class="btn btn-primary">Answer</button>
                    </a>
                </td>
                

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <h3 class="text-center">No Complaints</h3>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var create = document.querySelector('#create');
    var create_btn = document.querySelector('#create_btn');

    create_btn.addEventListener('click', function(){
        create.classList.toggle('d-none');
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\capastone-project\food-solidarity\resources\views/admin/answerComplaint/index.blade.php ENDPATH**/ ?>