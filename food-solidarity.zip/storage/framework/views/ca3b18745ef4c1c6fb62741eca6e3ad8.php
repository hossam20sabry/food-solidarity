<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>admin dashboard</h1>
    <form action="<?php echo e(route('admin.logout')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>

    <a href="<?php echo e(route('admin.profile.edit')); ?>">profile</a>
</body>
</html><?php /**PATH E:\main project\cenima-tickets\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>